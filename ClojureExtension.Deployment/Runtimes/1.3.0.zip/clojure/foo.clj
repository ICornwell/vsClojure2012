(ns clojure.foo (:gen-class :name "Foo"))

(defn f [] (str 'a 'b 'c))

