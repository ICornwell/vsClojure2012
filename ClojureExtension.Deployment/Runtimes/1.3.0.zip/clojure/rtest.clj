(ns clojure.rtest)

(defrecord R0 [])
(defrecord R1 [a])
(defrecord R2 [^long a])



